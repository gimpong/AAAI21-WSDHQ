import os
import sys
import gensim
import numpy as np
import pickle as pk
import tensorflow as tf
from sklearn.cluster import DBSCAN


config = {
    "device": "gpu:0", 
    "w2v_fpath": "/data/wangjinpeng/Datasets/GoogleNews-vectors-negative300.bin.gz",
    "nuswide": {
        "tags_fpath": "./nus-wide/TagList1k.txt",
        "val_tags_fpath": "./nus-wide/tags/ValidTags.txt",
        "val_tag_flags_fpath": "./nus-wide/tags/ValidTagFlags.txt",
        "val_tag_embs_fpath": "./nus-wide/tags/ValidTagEmbs.txt",
        "inval_tags_fpath": "./nus-wide/tags/InValidTags.txt",
        "idx_transform_fpath": "./nus-wide/tags/TagIdMergeMap.pkl",
        "final_tag_embs_fpath": "./nus-wide/tags/FinalTagEmbs.txt",
        "tau": 0.75,
        "max_n_neighbor": 20,
        "eps": 0.1
    }, 
    "flickr": {
        "tags_fpath": "./flickr25k/common_tags.txt",
        "val_tags_fpath": "./flickr25k/tags/ValidTags.txt",
        "val_tag_flags_fpath": "./flickr25k/tags/ValidTagFlags.txt",
        "val_tag_embs_fpath": "./flickr25k/tags/ValidTagEmbs.txt",
        "inval_tags_fpath": "./flickr25k/tags/InValidTags.txt",
        "idx_transform_fpath": "./flickr25k/tags/TagIdMergeMap.pkl",
        "final_tag_embs_fpath": "./flickr25k/tags/FinalTagEmbs.txt",
        "tau": 0.75,
        "max_n_neighbor": 20,
        "eps": 0.1
    }
}

oov_cvt_map = {
    'nikkor': 'Nikkor', 'olympus': 'Olympus', 'españa': 'España',
    'pentax': 'Pentax', 'xpro': 'Xpro', 'colour': 'color',
    'colours': 'colors', 'holga': 'Holga', 'grey': 'gray',
    'fujifilm': 'Fujifilm', 'hongkong': 'Hongkong', 'santiago': 'Santiago',
    'lumix': 'Lumix', 'nubes': 'Nubes', 'catalunya': 'Catalunya',
    'leica': 'Leica', 'photomatix': 'Photomatix', 'wien': 'Wien',
    'nederland': 'Nederland', 'taipei': 'Taipei', 'tramonto': 'Tramonto',
    'lomography': 'Lomography', 'zd': 'Zd', 'méxico': 'México',
    'maldives': 'Maldives', 'picnik': 'Picnik', 'lisboa': 'Lisboa',
    'tamron': 'Tamron', 'céu': 'Céu', 'd2x': 'D2X', 'newzealand': 'Newzealand',
    'chicagoist': 'Chicagoist', 'harbour': 'Harbour', 'catalonia': 'Catalonia', 
    'ricoh': 'Ricoh', 'yashica': 'Yashica', 'finepix': 'Finepix',
    'praia': 'Praia', 'bluesky': 'Bluesky', 'zurich': 'Zurich',
    'torino': 'Torino', 'polska': 'Polska', 'colourful': 'colorful',
    'architektur': 'Architektur', 'bilbao': 'Bilbao', 'toscana': 'Toscana',
    'agfa': 'Agfa', 'venezia': 'Venezia', 'cybershot': 'Cybershot',
    'sicilia': 'Sicilia', 'blume': 'Blume', 'sicily': 'Sicily',
    'tuscany': 'Tuscany', 'lluvia': 'Lluvia', 'banksy': 'Banksy',
    'sardegna': 'Sardegna', 'grd': 'Grd', 'belgique': 'Belgique',
    'firenze': 'Firenze', 'avision': 'Avision', 'galicia': 'Galicia',
    'schweiz': 'Schweiz', 'türkiye': 'Türkiye', 'cataluña': 'Cataluña',
    'urbano': 'Urbano', 'bostonist': 'Bostonist', 'münchen': 'München',
    'lensbaby': 'Lensbaby', 'blumen': 'Blumen', 'vivitar': 'Vivitar',
    'zürich': 'Zürich', 'warszawa': 'Warszawa', 'edificio': 'Edificio',
    'pisa': 'Pisa', 'farsi': 'Farsi', 'zuiko': 'Zuiko', 'hamed': 'Hamed',
    'hdr': 'HDR', 'xti': 'XTI', 'lca': 'LCA', 'cwd': 'CWD', 'msk': 'MSK',
    'gwl': 'GWL', 'pdx': 'PDX', 'telaviv': 'TELAVIV', 'ایران': 'Iran',
    '台灣': 'Taiwan', 'ايران': 'Iran', 'فارسی': 'Persian', '東京': 'Tokyo',
    'ایرانیان': 'Iranians', 'belgië': 'Belgium', '365days': 'year',
    'newyorkcity': 'newyork', 'superaplus': 'great', 'nikond80': 'nikon',
    'nikond200': 'nikon', 'nikond50': 'nikon', 'atardecer': 'dusk',
    'retrato': 'portrait', 'nikond40': 'nikon', 'canoneos350d': 'Canon',
    'buenosaires': 'Buenos', 'canoneos400d': 'Canon', 'unitedstates': 'US',
    'washingtondc': 'Washington', 'amigurumi': 'crocheting', 'newjersey': 'NJ',
    'canon400d': 'Canon', 'nuvole': 'clouds', 'unitedkingdom': 'UK',
    'biancoenero': 'white', 'flickrexplore': 'Flickr', 'canon30d': 'Canon',
    'newmexico': 'NM', 'riodejaneiro': 'Rio', 'southafrica': 'RSA',
    'contraluz': 'backlight', 'denhaag': 'Hague', 'britishcolumbia': 'BC',
    'northcarolina': 'NC', 'architettura': 'architecture', 'thehague': 'Hague',
    'specnature': 'nature', 'thenetherlands': 'Netherlands',
    'canoneos30d': 'Canon', 'paisaje': 'landscape', 'ritratto': 'portrait',
    'abbandono': 'abandonment', 'canon350d': 'Canon', 'bwdreams': 'dreams',
    'canoneos40d': 'Canon', 'foundinsf': 'SF', 'nycpb': 'nyc',
    'reflejo': 'reflect', 'dflickr': 'flickr', 'mywinners': 'winners',
    'pasteup': 'paste', 'mywinner': 'winner'}

oov_merge_map = {
    'abigfave': ['big', 'fave'],
    'selfportrait': ['self', 'portrait'],
    'blackandwhite': ['black', 'white'],
    'naturesfinest': ['natures', 'finest'],
    'impressedbeauty': ['impressed', 'beauty'],
    'anawesomeshot': ['awesome', 'shot'],
    'diamondclassphotographer': ['diamond', 'class', 'photographer'],
    'supershot': ['super', 'shot'],
    'flickrdiamond': ['Flickr', 'diamond'],
    'streetart': ['street', 'art'],
    'longexposure': ['long', 'exposure'],
    'blueribbonwinner': ['blue', 'ribbon', 'winner'],
    'aplusphoto': ['great', 'photo'],
    'superbmasterpiece': ['superb', 'masterpiece'],
    'flickrsbest': ['Flickr', 'best'],
    'blackwhite': ['black', 'white'],
    'nikonstunninggallery': ['nikon', 'stunning', 'gallery'],
    'specanimal': ['spec', 'animal'],
    'searchthebest': ['search', 'best'],
    'avianexcellence': ['avian', 'excellence'],
    'crossprocessed': ['cross', 'processed'],
    'outstandingshots': ['outstanding', 'shots'],
    'mediumformat': ['medium', 'format'],
    'superhearts': ['super', 'hearts'],
    'nightshot': ['night', 'shot'],
    'platinumphoto': ['platinum', 'photo'],
    'ilovenature': ['love', 'nature'],
    'goldstaraward': ['Goldstar', 'award'],
    'theperfectphotographer': ['perfect', 'photographer'],
    'burningman': ['burning', 'man'],
    'outdoorphotography': ['outdoor', 'photography'],
    'bodylanguage': ['body', 'language'],
    'goldenphotographer': ['golden', 'photographer'],
    'challengeyouwinner': ['challenge', 'winner'],
    '24hoursofflickr': ['day', 'Flickr'],
    'magicdonkey': ['magic', 'donkey'],
    'ultimateshot': ['ultimate', 'shot'],
    'stilllife': ['still', 'life'],
    'catchycolors': ['catchy', 'colors'],
    'firstquality': ['first', 'quality'],
    'animalkingdomelite': ['animal', 'kingdom', 'elite'],
    'guesswherelondon': ['guess', 'London'],
    'creativecommons': ['creative', 'commons'],
    'shieldofexcellence': ['shield', 'excellence'],
    'squareformat': ['square', 'format'],
    'betterthangood': ['better', 'good'],
    'noiretblanc': ['black', 'white'],
    'tenpositive': ['ten', 'positive'],
    'stereographicprojection': ['stereo', 'graphic', 'projection'],
    'instantfave': ['instant', 'fave'],
    'stuckincustoms': ['stuck', 'customs'],
    'excellentphotographerawards': ['excellent', 'photographer', 'awards'],
    'lightpainting': ['light', 'painting'],
    'crossprocessing': ['cross', 'processing'],
    'flickrgrouproulette': ['Flickr', 'group', 'roulette'],
    'naturalbeauty': ['natural', 'beauty'],
    'actionfigure': ['action', 'figure'],
    'coneyisland': ['coney', 'island'],
    'streetphotography': ['street', 'photography'],
    'naturallight': ['natural', 'light'],
    'tiltshift': ['tilt', 'shift'],
    'standardpoodle': ['standard', 'poodle'],
    'lakemichigan': ['lake', 'michigan'],
    'urbandecay': ['urban', 'decay'],
    'urbanfragments': ['urban', 'fragments'],
    'carshow': ['car', 'show'],
    'darkmatter': ['dark', 'matter'],
    'flickrmeetup': ['Flickr', 'meetup'],
    'expiredfilm': ['expired', 'film'],
    'hoodriver': ['hood', 'river']}


def select_and_save_valid_tags(
    w2v_fpath, # in
    tags_fpath, # in
    val_tags_fpath, # out
    val_tag_flags_fpath, # out
    val_tag_embs_fpath, # out
    inval_tags_fpath # out
    ):
    if os.path.exists(val_tag_flags_fpath) and os.path.exists(val_tag_embs_fpath):
        val_tag_flags = np.loadtxt(val_tag_flags_fpath)
        val_tag_embs = np.loadtxt(val_tag_embs_fpath)
        return None, val_tag_embs, val_tag_flags, None
    
    word2vec = gensim.models.KeyedVectors.load_word2vec_format(w2v_fpath, binary=True)
    with open(tags_fpath, 'r') as tag_file:
        tags = list(map(lambda s: s.split()[0], tag_file.readlines()))
    print("number of tags:", len(tags))
    val_tag_flags = np.ones(len(tags), dtype=np.int32)
    
    val_tags = []
    inval_tags = []
    val_tag_embs = []
    with open(val_tags_fpath, 'w') as val_tag_file, open(inval_tags_fpath, 'w') as inval_tag_file:
        for idx, tag in enumerate(tags):
            if tag in word2vec:
                val_tags.append(tag)
                val_tag_embs.append(word2vec.get_vector(tag))
                print(tag, file=val_tag_file)
            elif tag in oov_cvt_map:
                val_tags.append(tag)
                val_tag_embs.append(word2vec.get_vector(oov_cvt_map[tag]))
                print(tag, file=val_tag_file)
            elif tag in oov_merge_map:
                val_tags.append(tag)
                val_tag_embs.append(np.mean(word2vec[oov_merge_map[tag]], axis=0))
                print(tag, file=val_tag_file)
            else:
                val_tag_flags[idx] = 0
                inval_tags.append(tag)
                print((idx, tag), file=inval_tag_file)
                print((idx, tag))
    
    print("number of valid tags: %d, invalid tags: %d" % (len(val_tags), len(inval_tags)))
    np.savetxt(val_tag_flags_fpath, val_tag_flags)
    val_tag_embs = np.array(val_tag_embs)
    if not os.path.exists(val_tag_embs_fpath):
        np.savetxt(val_tag_embs_fpath, val_tag_embs)
    return val_tags, val_tag_embs, val_tag_flags, inval_tags


def enhance_tag(val_tag_embeddings, 
                tau, 
                max_n_neighbor, 
                device):
    # calculate tag similarities
    with tf.device(device):
        norm_val_tag_embeddings = tf.nn.l2_normalize(val_tag_embeddings, axis=-1) # TODO: detach a original one?
        tag_similarity = tf.matmul(norm_val_tag_embeddings, tf.transpose(norm_val_tag_embeddings))
        
        neighbor, neighbor_idx = tf.nn.top_k(tag_similarity, max_n_neighbor, sorted=False)
        kth_neighbor = tf.reduce_min(neighbor, axis=-1, keepdims=True)
        neighbor_mask = tf.greater_equal(tag_similarity, kth_neighbor)
        threshold_mask = tf.greater_equal(tag_similarity, tf.cast(tau, dtype=tag_similarity.dtype))
        
        # calculate summarizing weights for tag embeddings
        adjacency = tf.cast(tf.logical_and(neighbor_mask, threshold_mask), dtype=tag_similarity.dtype)
        sum_weights = adjacency / tf.reduce_sum(adjacency, axis=-1, keepdims=True)
        # get enhanced tag embeddings
        enhanced_tag_embeddings = tf.matmul(sum_weights, val_tag_embeddings)
        return tag_similarity, sum_weights, enhanced_tag_embeddings


def tag_preprocessing(
    tau, 
    max_n_neighbor, 
    eps, 
    # n_clusters, 
    idx_transform_fpath, # out
    final_tag_embs_fpath, 
    w2v_fpath, # in
    tags_fpath, # in
    val_tags_fpath, # out
    val_tag_flags_fpath, # out
    val_tag_embs_fpath, # out
    inval_tags_fpath, 
    device
    ): # out
    config = tf.compat.v1.ConfigProto()
    config.gpu_options.allow_growth = True
    config.log_device_placement = True

    _, val_tag_embs, _, _ = select_and_save_valid_tags(
        w2v_fpath=w2v_fpath, 
        tags_fpath=tags_fpath, 
        val_tags_fpath=val_tags_fpath, 
        val_tag_flags_fpath=val_tag_flags_fpath, 
        val_tag_embs_fpath=val_tag_embs_fpath, 
        inval_tags_fpath=inval_tags_fpath
    )
    print("number of valid tags:", len(val_tag_embs))

    with tf.compat.v1.Session(config=config) as sess:
        val_tag_embs = tf.convert_to_tensor(val_tag_embs)
        rets = sess.run(enhance_tag(val_tag_embs, 
                                    tf.constant(tau, dtype=tf.float64),
                                    tf.constant(max_n_neighbor, dtype=tf.int32),
                                    device=device))
        _, _, enhanced_tag_embs = rets

    clustering = DBSCAN(eps=eps, min_samples=1)
    clustering.fit(enhanced_tag_embs)

    idx_transform = dict()
    label_set = set(clustering.labels_)
    for label in label_set:
        idx_transform[label] = []
    for idx, label in enumerate(clustering.labels_):
        idx_transform[label].append(idx)
    with open(idx_transform_fpath, "wb") as file:
        pk.dump(idx_transform, file)

    label_set.discard(-1)
    final_tag_embs = dict()
    for label in label_set:
        final_tag_embs[label] = np.mean(enhanced_tag_embs[idx_transform[label]], 0)
    np.savetxt(final_tag_embs_fpath, np.array(list(final_tag_embs.values())))
    # print(idx_transform)
    print("number of final tags:", len(final_tag_embs))
    return len(final_tag_embs)


if __name__ == '__main__':
    dataset = sys.argv[1]
    config["w2v_fpath"] = sys.argv[2]
    config["device"] = 'gpu:' + sys.argv[3]

    if dataset not in ['nuswide', 'flickr']:
        print(f"unknown dataset '{dataset}', use 'nuswide' by default.")
        dataset = 'nuswide'
    
    tag_preprocessing(
        tau=config[dataset]['tau'],
        max_n_neighbor=config[dataset]['max_n_neighbor'],
        eps=config[dataset]['eps'],
        # n_clusters=config[dataset]['n_clusters'],
        idx_transform_fpath=config[dataset]['idx_transform_fpath'],  # out
        final_tag_embs_fpath=config[dataset]['final_tag_embs_fpath'],
        w2v_fpath=config['w2v_fpath'],  # in
        tags_fpath=config[dataset]['tags_fpath'],  # in
        val_tags_fpath=config[dataset]['val_tags_fpath'],  # out
        val_tag_flags_fpath=config[dataset]['val_tag_flags_fpath'],  # out
        val_tag_embs_fpath=config[dataset]['val_tag_embs_fpath'],  # out
        inval_tags_fpath=config[dataset]['inval_tags_fpath'],
        device=config['device']
    )
